#include <stdio.h>
int valor_do_bem;
int taxa_depreciacao;
int valor_do_bem_depreciado;
int valor_depreciado;
int valor_anos;
int valor_depreciado_final = valor_do_bem * (taxa_depreciacao / 100);
int valor_depreciado = valor_do_bem - valor_depreciado;
int main(void) {
printf("INFORME O VALOR DO BEM A SER DEPRECIADO: \N");
scanf("%i", &valor_do_bem);
 printf("INFORME O VALOR DA PRECIAÇÃO (EM ANOS): \N";
  
   
  return 0;
}